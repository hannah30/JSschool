
import Foundation
import UIKit

struct SettingListData {
  
  let settingList = ["자주하는질문", "친구초대하기", "후원하기", "선물하기", "지저스스쿨에 하고 싶은 말", "관리자"]
  let settingListImg: [UIImage] = [ UIImage(named:"more_icon2.png")!, UIImage(named:"more_icon3.png")!, UIImage(named:"more_icon5.png")!, UIImage(named:"more_icon4.png")!, UIImage(named:"more_icon6")!, UIImage(named:"more_icon7")! ]

//  let settingListImg: [UIImage] = [ #imageLiteral(resourceName: "more_icon2"), #imageLiteral(resourceName: "more_icon3"), #imageLiteral(resourceName: "more_icon5"), #imageLiteral(resourceName: "more_icon4"), #imageLiteral(resourceName: "more_icon6"), #imageLiteral(resourceName: "attend_no_icon") ]
}


