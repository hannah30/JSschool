// 카카오톡 로그인 버튼
import UIKit

class YellowBtn: UIButton {
  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
    
    self.layer.cornerRadius = self.frame.size.height / 2
    self.layer.borderWidth = 1 / UIScreen.main.scale
    self.layer.borderColor = #colorLiteral(red: 0.8941176471, green: 0.6666666667, blue: 0.2, alpha: 1)
    self.backgroundColor = #colorLiteral(red: 1, green: 0.9019607843, blue: 0.3294117647, alpha: 1)
    self.titleLabel?.textColor = #colorLiteral(red: 0.3882352941, green: 0.3921568627, blue: 0.4, alpha: 1)
    
    let cacaoImg: UIImageView = {
      let cacaoimg = UIImageView()
      //cacaoimg.frame = CGRect(x: 0, y: 0, width: 25, height: 25)
      cacaoimg.image = UIImage(named: "kakaolink_btn_medium")
      cacaoimg.contentMode = .scaleAspectFit
      return cacaoimg
    }()
    
    translatesAutoresizingMaskIntoConstraints = false
    cacaoImg.translatesAutoresizingMaskIntoConstraints = false
    self.addSubview(cacaoImg)
    //cacaoImg.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
    cacaoImg.widthAnchor.constraint(equalToConstant: 25).isActive = true
    cacaoImg.heightAnchor.constraint(equalToConstant: 25).isActive = true
    cacaoImg.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 30).isActive = true
    cacaoImg.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
    
    
  }
  
  
  
}

