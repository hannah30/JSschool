
import Foundation

struct AccountStepData{
  var id: String = ""
  var password: String = ""
  var nickname: String = ""
  var phoneNumber: String = ""
}
