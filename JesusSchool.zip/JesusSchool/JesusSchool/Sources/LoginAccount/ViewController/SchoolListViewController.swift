
import UIKit
import WebKit

class SchoolListViewController: UIViewController, WKUIDelegate {
  
  @IBOutlet weak var schoolListWeb: WKWebView!
  
  override func loadView() {
    let webConfiguration = WKWebViewConfiguration()
    schoolListWeb = WKWebView(frame: .zero, configuration: webConfiguration)
    schoolListWeb.uiDelegate = self
    view = schoolListWeb
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    let myURL = URL(string: "http://jesuskids.cafe24.com/m/page/school_list.html")
    let myRequest = URLRequest(url: myURL!)
    schoolListWeb.load(myRequest)
    
  }
  
  
  
}

