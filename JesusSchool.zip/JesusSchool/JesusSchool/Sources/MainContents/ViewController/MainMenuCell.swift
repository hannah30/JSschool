import UIKit
import PagingKit

class MainMenuCell: PagingMenuViewCell {

  @IBOutlet weak var MainTopTitleLabel: UILabel!
  
}
