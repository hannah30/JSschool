import UIKit
import PagingKit

class MainPageControllViewController: UIViewController {
  
  var menuViewController: PagingMenuViewController!
  var contentViewController: PagingContentViewController!
  
  var firstViewController = NewsViewController()
  
  var contentsDatasource: [(menuTitle: String, vc: UIViewController)]?
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    setUpViewController()
    
    menuViewController.register(nib: UINib(nibName: "MainMenuCell", bundle: nil), forCellWithReuseIdentifier: "MainMenuCell")
    menuViewController.registerFocusView(nib: UINib(nibName: "FocusView", bundle: nil))
    
    menuViewController.reloadData(with: 0)
    contentViewController.reloadData(with: 0)
  }
  
  func setUpViewController(){
    let mainStotyboard = UIStoryboard(name: "Main", bundle: nil)
    let newsVC = mainStotyboard.instantiateViewController(withIdentifier: "News")
    let attendanceVC = mainStotyboard.instantiateViewController(withIdentifier: "Attendance")
    let scheduleVC = mainStotyboard.instantiateViewController(withIdentifier: "Schedule")
    let thisIsVC = mainStotyboard.instantiateViewController(withIdentifier: "ThisisSetting")
    
    contentsDatasource = [
      (menuTitle: "소식", vc: newsVC),
      (menuTitle: "출석", vc: attendanceVC),
      (menuTitle: "일정", vc: scheduleVC),
      (menuTitle: "더보기", vc: thisIsVC),
    ]
  }
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if let vc = segue.destination as? PagingMenuViewController {
      menuViewController = vc
      menuViewController.dataSource = self
      menuViewController.delegate = self
      
    } else if let vc = segue.destination as? PagingContentViewController {
      contentViewController = vc
      contentViewController.dataSource = self
      contentViewController.delegate = self
    }
  }
  
  
}

extension MainPageControllViewController: PagingMenuViewControllerDataSource {
  func numberOfItemsForMenuViewController(viewController: PagingMenuViewController) -> Int {
    return contentsDatasource?.count ?? 0
  }
  
  func menuViewController(viewController: PagingMenuViewController, cellForItemAt index: Int) -> PagingMenuViewCell {
    let cell = viewController.dequeueReusableCell(withReuseIdentifier: "MainMenuCell", for: index) as! MainMenuCell
    cell.MainTopTitleLabel.text = contentsDatasource?[index].menuTitle
    return cell
  }
  
  func menuViewController(viewController: PagingMenuViewController, widthForItemAt index: Int) -> CGFloat {
    return self.view.bounds.size.width / CGFloat(contentsDatasource?.count ?? 1)
  }
  
  
}

extension MainPageControllViewController: PagingContentViewControllerDataSource {
  func numberOfItemsForContentViewController(viewController: PagingContentViewController) -> Int {
    return contentsDatasource?.count ?? 0
  }
  
  func contentViewController(viewController: PagingContentViewController, viewControllerAt index: Int) -> UIViewController {
    return contentsDatasource![index].vc
  }
}

extension MainPageControllViewController: PagingContentViewControllerDelegate {
  func contentViewController(viewController: PagingContentViewController, didManualScrollOn index: Int, percent: CGFloat) {
    menuViewController.scroll(index: index, percent: percent, animated: false)
  }
}

extension MainPageControllViewController: PagingMenuViewControllerDelegate {
  func menuViewController(viewController: PagingMenuViewController, didSelect page: Int, previousPage: Int) {
    contentViewController.scroll(to: page, animated: true)
  }
}
