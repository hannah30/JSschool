
import Foundation

struct MyAccountData {
  
  let MyAccountHeaderData = ["나의 계정관리", "알림설정", "로그아웃&탈퇴"]
  
  let MyAccountInformation = ["휴대폰번호", "아이디", "닉네임", "나의교회학교", "호칭", "비밀번호변경"]
  let MyAccountNotice = ["알림"]
  let MyAccountLogout = ["로그아웃", "회원탈퇴"]
  
}

